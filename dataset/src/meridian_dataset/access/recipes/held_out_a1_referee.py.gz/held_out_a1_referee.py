#!/usr/bin/env python3
"""Independent referee: build an answer key from the raw access world.

Usage: python3 -I referee.py WORLD_DIR OUT_JSON

Standard library only. Reads WORLD_DIR, writes only OUT_JSON. Every finding is
derived from rules applied to the data (see referee-notes.md for judgment calls).
"""
import csv
import collections
import datetime as dt
import io
import json
import re
import sys
import unicodedata
from pathlib import Path

DELIMS = [",", ";", "\t", "|"]

# ---------------------------------------------------------------- utilities


def norm(s):
    return (s or "").strip().lower()


def hkey(s):
    """Normalise a header cell for synonym lookup."""
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]", "", s.lower())


# Latin letters that NFKD does not decompose.
_SPECIAL = {"đ": "d", "ø": "o", "ł": "l", "ß": "ss", "æ": "ae", "œ": "oe",
            "þ": "th", "ð": "d", "ı": "i", "ħ": "h", "ŀ": "l"}


def ascii_form(name):
    """ASCII form of a name, following the public recipe's description."""
    out = []
    for ch in name:
        low = ch.lower()
        if low in "'’. -":
            continue
        if low in _SPECIAL:
            out.append(_SPECIAL[low])
            continue
        d = unicodedata.normalize("NFKD", low)
        base = "".join(c for c in d if not unicodedata.combining(c))
        if base and all(ord(c) < 128 for c in base):
            out.append(base)
        else:
            out.append(None if not out or out[-1] is not None else None)
            out[-1] = ("HEX", "%x" % ord(ch))
    # Non-ASCII letters: 'u' followed by the concatenated code points of the run.
    res, run = [], []
    for item in out:
        if isinstance(item, tuple):
            run.append(item[1])
        else:
            if run:
                res.append("u" + "".join(run))
                run = []
            res.append(item)
    if run:
        res.append("u" + "".join(run))
    return "".join(res).lower()


def decode_bytes(b):
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return b.decode("utf-16")
    if b[:3] == b"\xef\xbb\xbf":
        return b[3:].decode("utf-8")
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("cp1252")


# ---------------------------------------------------------------- dates

_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}


def parse_date(s):
    """Return a datetime.date or None. Handles the formats seen in exports."""
    s = (s or "").strip()
    if not s:
        return None
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}([T ].*)?", s):
            return dt.date(int(s[:4]), int(s[5:7]), int(s[8:10]))
        if re.fullmatch(r"\d{4}/\d{2}/\d{2}( .*)?", s):
            return dt.date(int(s[:4]), int(s[5:7]), int(s[8:10]))
        m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.(\d{2,4})", s)
        if m:
            y = int(m.group(3))
            y = y + 2000 if y < 100 else y
            return dt.date(y, int(m.group(2)), int(m.group(1)))
        m = re.fullmatch(r"([A-Za-z]{3})[a-z]* (\d{1,2}), (\d{4})", s)
        if m:
            return dt.date(int(m.group(3)), _MONTHS[m.group(1).lower()], int(m.group(2)))
        if re.fullmatch(r"\d{8}", s):
            return dt.date(int(s[:4]), int(s[4:6]), int(s[6:8]))
        if re.fullmatch(r"\d{9,11}", s):
            return dt.datetime.fromtimestamp(int(s), dt.timezone.utc).date()
        if re.fullmatch(r"\d{4,6}(\.\d+)?", s):
            return dt.date(1899, 12, 30) + dt.timedelta(days=int(float(s)))
    except (ValueError, KeyError, OverflowError):
        return None
    return None


# ---------------------------------------------------------------- exports

_FIELD_SYNONYMS = [
    ("email", ["accountemail", "emailaddress", "email", "mail", "emailadresse", "mailadresse",
               "courriel", "adresseemail", "correo"]),
    ("username", ["userid", "username", "identifiant", "login", "benutzername", "user",
                  "handle", "uid", "usuario"]),
    ("first_name", ["given", "givenname", "firstname", "prenom", "vorname", "nombre"]),
    ("last_name", ["surname", "familyname", "lastname", "nom", "nachname", "apellido"]),
    ("full_name", ["person", "fullname", "display", "displayname", "anzeigename", "name",
                   "nomcomplet", "nomaffiche"]),
    ("role_level", ["isadmin", "role", "accesstier", "berechtigung", "privilege", "profil",
                    "permission", "level", "rolle", "admin"]),
    ("last_login", ["lastseen", "lastlogin", "lastloginat", "letzteanmeldung", "lastsignin",
                    "derniereconnexion", "lastactive", "lastactivity"]),
    ("created", ["dateadded", "createdat", "firstseen", "created", "erstellt", "datecreation",
                 "erstelltam", "since"]),
    ("status", ["state", "acctstate", "kontostatus", "etat", "status", "accountstatus"]),
    ("department", ["team", "department", "abteilung", "dept", "equipe", "service"]),
    ("title", ["jobtitle", "title", "position", "poste", "titel"]),
]


def header_field(cell):
    k = hkey(cell)
    for field, syns in _FIELD_SYNONYMS:
        if k in syns:
            return field
    # looser rules
    if "mail" in k:
        return "email"
    if "login" in k or "seen" in k or "anmeld" in k or "connexion" in k or "signin" in k:
        return "last_login"
    return None


_ADMIN_WORDS = {"admin", "administrator", "administrateur", "owner", "yes", "ja", "oui",
                "true", "superuser", "y", "1", "manager", "editor"}
_INACTIVE_WORDS = {"inactive", "disabled", "gesperrt", "suspended", "deactivated", "inaktiv",
                   "desactive", "désactivé", "blocked", "locked", "no", "false", "deprovisioned",
                   "archived", "removed", "deleted"}


def parse_export(path):
    text = decode_bytes(path.read_bytes())
    lines = re.split(r"\r\n|\n|\r", text)
    header_idx, delim, header = None, None, None
    for i, line in enumerate(lines):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        best = None
        for d in DELIMS:
            if d not in line:
                continue
            cells = next(csv.reader([line], delimiter=d))
            fields = [header_field(c) for c in cells]
            score = sum(1 for f in fields if f)
            if score >= 2 and ("email" in fields or "username" in fields):
                if best is None or score > best[0]:
                    best = (score, d, cells, fields)
        if best:
            header_idx, delim, header = i, best[1], best[3]
            break
    if header_idx is None:
        return {"rows": [], "username_only": False, "fields": []}
    rows = []
    for line in lines[header_idx + 1:]:
        if not line.strip():
            continue
        cells = next(csv.reader([line], delimiter=delim))
        if len(cells) != len(header):
            continue  # footer or other non-data line
        if not any(c.strip() for c in cells):
            continue  # blank noise row
        rec = {}
        for f, c in zip(header, cells):
            if f and f not in rec:
                rec[f] = c
        rows.append(rec)
    username_only = "email" not in header and "username" in header
    return {"rows": rows, "username_only": username_only, "fields": header}


# ---------------------------------------------------------------- username patterns


def candidate_patterns():
    pats = []
    for a in ("{first}", "{f}"):
        for b in ("{last}", "{l}"):
            if a == "{f}" and b == "{l}":
                continue
            for sep in ("", ".", "_", "-"):
                for order in ((a, b), (b, a)):
                    pats.append(order[0] + sep + order[1] + "{n}")
    return pats


def render(pattern, tok):
    s = pattern
    for k in ("first", "last", "f", "l", "n"):
        s = s.replace("{" + k + "}", tok[k])
    return s.lower()


# ---------------------------------------------------------------- access policy
# Copied verbatim from the public guide, section "Access policy (role -> apps)".
POLICY = """
Every current worker has an Okta user, a Google user and a Slack user.

Birthright SSO apps, for every employee: amber-ledger, birch-vault, cobalt-notes, dune-hub, ember-atlas, fjord-docs, garnet-desk, harbor-pulse.
Contractors get the first 6 of them: amber-ledger, birch-vault, cobalt-notes, dune-hub, ember-atlas, fjord-docs.

SSO access is a group assignment with the `member` role. Non-SSO apps are rows in that app's export.

| Role | SSO apps beyond birthright | Non-SSO apps (export rows) |
|---|---|---|
| eng-backend | indigo-track, maple-forms, quartz-ledger | umber-relay, sable-track, quartz-vault, onyx-canvas, maple-hub, indigo-sheets |
| eng-frontend | nimbus-studio, raven-vault, vale-docs, amber-board | vale-ledger, tundra-signal, raven-notes, pebble-board, nimbus-atlas, pebble-docs |
| eng-sre | sable-notes, willow-desk, birch-forms, fjord-ledger, juniper-atlas | willow-vault, umber-canvas, sable-hub, quartz-forms, onyx-docs, willow-forms |
| eng-data | yarrow-pulse, cobalt-studio, garnet-vault, kestrel-docs, onyx-signal, sable-studio | yarrow-notes, vale-board, tundra-atlas, raven-studio, ember-docs |
| sales-ae | dune-sheets, harbor-notes, lumen-desk, pebble-canvas, tundra-sheets, lumen-board, pebble-relay | zephyr-hub, willow-forms, umber-docs, sable-sheets, lumen-forms |
| sales-sdr | indigo-hub, maple-pulse, quartz-board, indigo-track, maple-forms, quartz-ledger, umber-atlas, zephyr-track | amber-desk, yarrow-studio, vale-desk, tundra-relay, sable-hub |
| sales-ops | nimbus-track, raven-forms, juniper-signal | birch-pulse, zephyr-sheets, willow-pulse, umber-ledger, amber-forms |
| cs-csm | sable-studio, kestrel-canvas, onyx-sheets, sable-notes | cobalt-track, amber-vault, yarrow-track, vale-vault, harbor-hub |
| cs-support | lumen-board, pebble-relay, tundra-hub, yarrow-pulse, cobalt-studio | dune-signal, birch-notes, zephyr-signal, willow-notes, onyx-canvas |
| cs-onboarding | quartz-ledger, umber-atlas, zephyr-track, dune-sheets, harbor-notes, lumen-desk | ember-canvas, cobalt-hub, amber-forms, yarrow-hub, vale-vault |
| mkt-pmm | vale-docs, amber-board, ember-relay, indigo-hub, maple-pulse, quartz-board, indigo-track | fjord-board, dune-atlas, birch-studio, zephyr-atlas, dune-canvas |
| mkt-content | birch-forms, fjord-ledger, juniper-atlas, nimbus-track, raven-forms, juniper-signal, nimbus-studio, raven-vault | garnet-forms, ember-docs, cobalt-sheets, amber-pulse, kestrel-vault |
| mkt-growth | garnet-vault, kestrel-docs, onyx-signal | harbor-studio, fjord-desk, dune-relay, birch-track, willow-vault |
| fin-analyst | lumen-desk, pebble-canvas, tundra-sheets, lumen-board | indigo-sheets, garnet-pulse, ember-ledger, cobalt-signal, ember-canvas |
| fin-accountant | quartz-board, indigo-track, maple-forms, quartz-ledger, umber-atlas | juniper-relay, harbor-track, fjord-vault, dune-canvas, lumen-vault |
| ppl-partner | juniper-signal, nimbus-studio, raven-vault, vale-docs, amber-board, ember-relay | kestrel-ledger, indigo-signal, garnet-notes, ember-board, sable-track |
| ppl-recruiter | onyx-sheets, sable-notes, willow-desk, birch-forms, fjord-ledger, juniper-atlas, nimbus-track | lumen-vault, juniper-canvas, harbor-hub, fjord-forms, amber-vault |
| it-lead | tundra-hub, yarrow-pulse, cobalt-studio, garnet-vault, kestrel-docs, onyx-signal, sable-studio, kestrel-canvas | maple-notes, kestrel-board, indigo-atlas, garnet-studio, harbor-track |
| it-engineer | zephyr-track, dune-sheets, harbor-notes | nimbus-hub, lumen-forms, juniper-docs, harbor-sheets, onyx-relay |
| prod-pm | ember-relay, indigo-hub, maple-pulse, quartz-board | onyx-atlas, maple-studio, kestrel-desk, indigo-relay, vale-desk |
| prod-analyst | juniper-atlas, nimbus-track, raven-forms, juniper-signal, nimbus-studio | pebble-docs, nimbus-sheets, lumen-pulse, juniper-ledger, dune-relay |
| des-product | onyx-signal, sable-studio, kestrel-canvas, onyx-sheets, sable-notes, willow-desk | quartz-desk, onyx-relay, maple-track, kestrel-vault, kestrel-desk |
| des-brand | tundra-sheets, lumen-board, pebble-relay, tundra-hub, yarrow-pulse, cobalt-studio, garnet-vault | raven-pulse, pebble-ledger, nimbus-signal, lumen-notes, raven-studio |
"""

# HRIS records carry department/team/job title, not a role id. The catalog names
# each role; the HRIS teams map onto them one to one (IT is split by job title).
TEAM_ROLE = {
    ("Engineering", "Platform"): "eng-backend",
    ("Engineering", "Web"): "eng-frontend",
    ("Engineering", "Reliability"): "eng-sre",
    ("Engineering", "Data"): "eng-data",
    ("Sales", "Enterprise"): "sales-ae",
    ("Sales", "Outbound"): "sales-sdr",
    ("Sales", "Revenue Operations"): "sales-ops",
    ("Customer Success", "Accounts"): "cs-csm",
    ("Customer Success", "Support"): "cs-support",
    ("Customer Success", "Onboarding"): "cs-onboarding",
    ("Marketing", "Product Marketing"): "mkt-pmm",
    ("Marketing", "Content"): "mkt-content",
    ("Marketing", "Growth"): "mkt-growth",
    ("Finance", "FP&A"): "fin-analyst",
    ("Finance", "Accounting"): "fin-accountant",
    ("People", "People Partners"): "ppl-partner",
    ("People", "Talent"): "ppl-recruiter",
    ("Product", "Product"): "prod-pm",
    ("Product", "Insights"): "prod-analyst",
    ("Design", "Product Design"): "des-product",
    ("Design", "Brand"): "des-brand",
}


def parse_policy(text):
    def apps_after_colon(line):
        return [a.strip().rstrip(".") for a in line.split(":", 1)[1].split(",") if a.strip()]
    birthright, contractor = [], []
    sso, exp = {}, {}
    for line in text.splitlines():
        if line.startswith("Birthright SSO apps"):
            birthright = apps_after_colon(line)
        elif line.startswith("Contractors get"):
            contractor = apps_after_colon(line)
        elif line.startswith("|") and not line.startswith("|---") and "Role" not in line:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            role = cells[0]
            sso[role] = {a.strip() for a in cells[1].split(",") if a.strip()}
            exp[role] = {a.strip() for a in cells[2].split(",") if a.strip()}
    return set(birthright), set(contractor), sso, exp


# ---------------------------------------------------------------- the referee


class World:
    def __init__(self, wd):
        wd = Path(wd)
        self.hris = json.loads((wd / "hris.json").read_text(encoding="utf-8"))
        self.okta = json.loads((wd / "okta.json").read_text(encoding="utf-8"))
        self.google = json.loads((wd / "google.json").read_text(encoding="utf-8"))
        self.slack = json.loads((wd / "slack_scim.json").read_text(encoding="utf-8"))
        self.exports = {}
        for p in sorted((wd / "exports").glob("*.csv")):
            self.exports[p.stem] = parse_export(p)
        self.ref_date = dt.date.fromisoformat(self.hris.get("reference_date", "2026-12-01"))
        self.month_start = self.ref_date.replace(day=1) - dt.timedelta(days=1)
        self.month_start = self.month_start.replace(day=1)


def build(world_dir):
    W = World(world_dir)
    ref = W.ref_date
    mstart = W.month_start
    records = W.hris["records"]
    events = W.hris["events"]
    R = {r["employee_id"]: r for r in records}
    ev_by = collections.defaultdict(list)
    for e in events:
        ev_by[e["employee_id"]].append(e)

    findings = {}
    notes_debug = collections.defaultdict(list)

    def add(ftype, eid, account, system, app_id, action):
        key = (account, system, app_id)
        if key in findings:
            return  # one finding per (account, system, app); earlier rules win
        findings[key] = {"type": ftype, "employee_id": eid or "", "account": account,
                         "system": system, "app_id": app_id, "expected_action": action}

    # ------------------------------------------------ HR anomalies
    # Bulk HR events: many terminations from a non-HR source on one day.
    bulk_groups = collections.defaultdict(list)
    for e in events:
        if e["kind"] == "terminate" and e.get("source", "hr") != "hr":
            bulk_groups[(e["date"], e.get("source"))].append(e["employee_id"])
    bulk_people = set()
    bulk_findings = []
    for k, ids in sorted(bulk_groups.items()):
        if len(ids) >= 5:
            bulk_people.update(ids)
            bulk_findings.append(k)

    # Duplicate HR records: two current records, same name and work email; the one
    # created by an in-month hire event whose start date lies before the month is the copy.
    dup_records = set()
    by_email = collections.defaultdict(list)
    for r in records:
        by_email[norm(r["work_email"])].append(r)
    for em, rs in by_email.items():
        cur = [r for r in rs if r["status"] in ("active", "on_leave")]
        if len(cur) < 2:
            continue
        for r in cur:
            hires = [e for e in ev_by[r["employee_id"]] if e["kind"] == "hire"]
            if hires and r["start_date"] < mstart.isoformat():
                dup_records.add(r["employee_id"])

    # Terminated status with an end date still in the future.
    future_term = {r["employee_id"] for r in records
                   if r["status"] == "terminated" and r["end_date"] and r["end_date"] > ref.isoformat()}

    hr_errors = sorted(dup_records | future_term)

    # ------------------------------------------------ person classification
    def is_current(r):
        if r["employee_id"] in dup_records:
            return False
        if r["status"] in ("active", "on_leave"):
            return True
        return r["employee_id"] in future_term  # still working until the future end date

    def role_of(r):
        if r["department"] == "IT":
            t = r["job_title"].lower()
            return "it-lead" if ("manager" in t or "lead" in t or "head" in t) else "it-engineer"
        return TEAM_ROLE.get((r["department"], r["team"]), "")

    # ------------------------------------------------ identity indexes
    # email -> employee ids (work emails, plus old addresses from Google aliases)
    email_owners = collections.defaultdict(set)
    for r in records:
        email_owners[norm(r["work_email"])].add(r["employee_id"])
    alias_of = {}
    for g in W.google["users"]:
        for a in g.get("aliases", []):
            alias_of[norm(a)] = norm(g["primaryEmail"])

    def pick_owner(eids, created=None):
        eids = [e for e in eids if e not in dup_records]
        if not eids:
            return None
        if len(eids) == 1:
            return eids[0]
        cur = [e for e in eids if is_current(R[e])]
        if len(cur) == 1:
            return cur[0]
        pool = cur or eids
        # latest start date wins (rehire reuses the address)
        return sorted(pool, key=lambda e: (R[e]["start_date"], e))[-1]

    def owner_of_email(em):
        em = norm(em)
        if em in email_owners:
            return pick_owner(email_owners[em])
        if em in alias_of and alias_of[em] in email_owners:
            return pick_owner(email_owners[alias_of[em]])
        return None

    # name tokens per person for username patterns
    def tokens_for(r, family=None):
        """Username placeholders: ASCII given and family name, {n} = the duplicate
        number the work email carries (first.last<n>@)."""
        first = ascii_form(r["given_name"])
        last = ascii_form(family if family is not None else r["family_name"])
        loc = norm(r["work_email"]).split("@")[0]
        n = ""
        stem = first + "." + last
        if loc.startswith(stem) and loc[len(stem):].isdigit():
            n = loc[len(stem):]
        return {"first": first, "last": last, "f": first[:1], "l": last[:1], "n": n}

    person_tokens = collections.defaultdict(list)  # eid -> list of token dicts
    for r in records:
        person_tokens[r["employee_id"]].append(tokens_for(r))
    # old family names from Google aliases (name changes)
    for g in W.google["users"]:
        prim = norm(g["primaryEmail"])
        for a in g.get("aliases", []):
            oid = pick_owner(email_owners.get(prim, set()))
            if not oid:
                continue
            loc = norm(a).split("@")[0]
            m = re.fullmatch(r"([a-z0-9]+)\.([a-z]+)(\d*)", loc)
            if m:
                person_tokens[oid].append({"first": m.group(1), "last": m.group(2),
                                           "f": m.group(1)[:1], "l": m.group(2)[:1],
                                           "n": m.group(3)})

    def name_variants(r):
        g = r["given_name"]
        p = r["preferred_name"] or g
        fam = r["family_name"]
        return {norm(x) for x in (g, p)}, norm(fam)

    # ------------------------------------------------ Okta
    apps = {a["id"]: a["name"] for a in W.okta["apps"]}
    okta_users = W.okta["users"]
    ou_by_id = {u["id"]: u for u in okta_users}
    okta_owner = {}
    for u in okta_users:
        okta_owner[u["id"]] = owner_of_email(u["profile"].get("login") or u["profile"].get("email"))
    assign = collections.defaultdict(dict)  # okta user id -> app name -> assignment
    for a in W.okta["assignments"]:
        assign[a["userId"]][apps.get(a["appId"], a["appId"])] = a
    okta_by_login = {norm(u["profile"]["login"]): u for u in okta_users}

    def okta_active(u):
        return u["status"] not in ("DEPROVISIONED", "SUSPENDED")

    # ------------------------------------------------ Google / Slack
    g_users = W.google["users"]
    g_owner = {g["primaryEmail"]: owner_of_email(g["primaryEmail"]) for g in g_users}
    s_users = W.slack["Resources"]

    def slack_email(s):
        for e in s.get("emails", []):
            if e.get("primary"):
                return e["value"]
        return s["emails"][0]["value"] if s.get("emails") else s["userName"] + "@"

    s_owner = {}
    for s in s_users:
        s_owner[s["id"]] = owner_of_email(slack_email(s))

    # ------------------------------------------------ exports: owners
    pats = candidate_patterns()
    export_pattern = {}
    export_rows = {}  # app -> list of dicts {account, owner, row}
    for app, ex in W.exports.items():
        rows = ex["rows"]
        out = []
        seen = set()
        if not ex["username_only"]:
            for row in rows:
                acct = norm(row.get("email", ""))
                if not acct or acct in seen:
                    continue
                seen.add(acct)
                out.append({"account": acct, "owner": owner_of_email(acct), "row": row})
        else:
            unames = [norm(row.get("username", "")) for row in rows]
            # choose the pattern that explains the most usernames
            best = None
            for p in pats:
                gen = set()
                for eid, toks in person_tokens.items():
                    for t in toks:
                        gen.add(render(p, t))
                score = sum(1 for u in unames if u and (u in gen or re.sub(r"\d+$", "", u) in gen))
                if best is None or score > best[0]:
                    best = (score, p)
            pat = best[1]
            export_pattern[app] = pat
            gen_map = collections.defaultdict(set)
            for eid, toks in person_tokens.items():
                for t in toks:
                    gen_map[render(pat, t)].add(eid)
            for row in rows:
                acct = norm(row.get("username", ""))
                if not acct or acct in seen:
                    continue
                seen.add(acct)
                cands = set(gen_map.get(acct, set()))
                if not cands:
                    base = re.sub(r"\d+$", "", acct)
                    cands = set(gen_map.get(base, set()))
                    # collision suffix: base username of someone else
                cands = {c for c in cands if c not in dup_records}
                owner = None
                if cands:
                    # disambiguate by display name in the row
                    fn = norm(row.get("first_name", ""))
                    ln = norm(row.get("last_name", ""))
                    full = norm(row.get("full_name", ""))
                    scored = []
                    for c in cands:
                        r = R[c]
                        givens, fam = name_variants(r)
                        sc = 0
                        if fn and fn in givens:
                            sc += 1
                        if ln and ln == fam:
                            sc += 1
                        if full and any(full == f"{g} {fam}" for g in givens):
                            sc += 2
                        scored.append((sc, c))
                    top = max(s for s, _ in scored)
                    owner = pick_owner([c for s, c in scored if s == top])
                out.append({"account": acct, "owner": owner, "row": row})
        export_rows[app] = out

    # ------------------------------------------------ role definitions (public access policy)
    person_okta = {}
    for u in okta_users:
        oid = okta_owner[u["id"]]
        if oid and okta_active(u):
            # prefer the account that matches the person's current work email
            if oid not in person_okta or norm(u["profile"]["login"]) == norm(R[oid]["work_email"]):
                person_okta[oid] = u

    person_rows = collections.defaultdict(dict)  # eid -> app -> account
    for app, rows in export_rows.items():
        for x in rows:
            if x["owner"]:
                person_rows[x["owner"]][app] = x["account"]

    birthright, contractor_birthright, role_sso_extra, role_exp_pol = parse_policy(POLICY)

    def want_sso_of(r):
        base = contractor_birthright if r["employment_type"] == "contractor" else birthright
        return set(base) | role_sso_extra.get(role_of(r), set())

    def want_exp_of(r):
        return set(role_exp_pol.get(role_of(r), set()))

    # ------------------------------------------------ Okta log
    hand_grants = []
    priv_changes = []
    for e in W.okta.get("system_log", []):
        via = ((e.get("transaction") or {}).get("detail") or {}).get("via", "")
        actor = e.get("actor", {})
        human = actor.get("type") == "User" or via == "admin console"
        if not human:
            continue
        app = user = None
        for t in e.get("target", []):
            if t.get("type") == "AppInstance":
                app = apps.get(t["id"], t["id"])
            elif t.get("type") == "User":
                user = t.get("id")
                if user not in ou_by_id:
                    lu = okta_by_login.get(norm(t.get("alternateId")))
                    user = lu["id"] if lu else user
        if not (app and user):
            continue
        if e["eventType"].endswith("user_membership.add"):
            hand_grants.append((user, app))
        elif "privilege" in e["eventType"]:
            priv_changes.append((user, app))

    # ------------------------------------------------ break-glass identities
    def is_break_glass(login):
        return bool(re.search(r"break[-_.]?glass", norm(login)))

    for u in okta_users:
        if is_break_glass(u["profile"]["login"]):
            add("break_glass", "", u["profile"]["login"], "okta", "", "never_touch")
    for g in g_users:
        if is_break_glass(g["primaryEmail"]):
            add("break_glass", "", g["primaryEmail"], "google", "", "never_touch")
    for s in s_users:
        if is_break_glass(slack_email(s)) or is_break_glass(s["userName"]):
            add("break_glass", "", s["userName"], "slack", "", "never_touch")
    for app, rows in export_rows.items():
        for x in rows:
            if is_break_glass(x["account"]):
                add("break_glass", "", x["account"], app, app, "never_touch")
    bg_okta_ids = {u["id"] for u in okta_users if is_break_glass(u["profile"]["login"])}

    # ------------------------------------------------ HR feed findings
    for (date, src) in bulk_findings:
        add("hris_mass_termination", "", "", "hris", "", "block_two_approvers")
    for eid in hr_errors:
        add("hr_data_error", eid, eid, "hris", "", "flag")

    # ------------------------------------------------ drift (Okta log, by hand)
    for (uid, app) in priv_changes:
        a = assign.get(uid, {}).get(app)
        u = ou_by_id.get(uid)
        if a and u and uid not in bg_okta_ids:
            add("drift", okta_owner[uid] or "", u["profile"]["login"], "okta", app, "flag")
    drift_pairs = set()
    for (uid, app) in hand_grants:
        a = assign.get(uid, {}).get(app)
        u = ou_by_id.get(uid)
        if a and u and uid not in bg_okta_ids:
            drift_pairs.add((uid, app))

    # ------------------------------------------------ per-person status helpers
    def term_kind(r):
        """'leaver' (terminated during the month), 'former' (before), or None."""
        if r["status"] != "terminated" or r["employee_id"] in future_term:
            return None
        end = r["end_date"]
        if end and end < mstart.isoformat():
            return "former"
        return "leaver"

    def contractor_past_end(r):
        return (r["employment_type"] == "contractor" and r["status"] != "terminated"
                and r["end_date"] and r["end_date"] < ref.isoformat())

    def on_leave(r):
        return r["status"] == "on_leave" and r["leave_start"] and r["leave_start"] <= ref.isoformat()

    # ------------------------------------------------ per account findings
    def handle_person_accounts(eid):
        r = R[eid]
        if eid in bulk_people:
            return  # bulk HR error: no removals for those people
        if eid in dup_records:
            return  # duplicate HR record: owns no accounts; reported as hr_data_error
        kind = term_kind(r)
        ftype = None
        if kind == "leaver":
            ftype = "leaver_access_left"
        elif kind == "former":
            ftype = "orphaned_account"
        if ftype:
            for u in okta_users:
                if okta_owner[u["id"]] == eid and okta_active(u):
                    add(ftype, eid, u["profile"]["login"], "okta", "", "suspend")
                    for app in sorted(assign[u["id"]]):
                        add(ftype, eid, u["profile"]["login"], "okta", app, "remove")
            for g in g_users:
                if g_owner[g["primaryEmail"]] == eid and not g["suspended"]:
                    add(ftype, eid, g["primaryEmail"], "google", "", "suspend")
            for s in s_users:
                if s_owner[s["id"]] == eid and s.get("active"):
                    add(ftype, eid, s["userName"], "slack", "", "remove")
            for app, rows in export_rows.items():
                for x in rows:
                    if x["owner"] == eid and row_active(x["row"]):
                        add(ftype, eid, x["account"], app, app, "flag")
            return
        if r["status"] == "terminated" and eid not in future_term:
            return
        if contractor_past_end(r):
            for u in okta_users:
                if okta_owner[u["id"]] == eid and okta_active(u):
                    add("contractor_past_end", eid, u["profile"]["login"], "okta", "", "remove")
                    for app in sorted(assign[u["id"]]):
                        add("contractor_past_end", eid, u["profile"]["login"], "okta", app, "remove")
            for g in g_users:
                if g_owner[g["primaryEmail"]] == eid and not g["suspended"]:
                    add("contractor_past_end", eid, g["primaryEmail"], "google", "", "remove")
            for s in s_users:
                if s_owner[s["id"]] == eid and s.get("active"):
                    add("contractor_past_end", eid, s["userName"], "slack", "", "remove")
            for app, rows in export_rows.items():
                for x in rows:
                    if x["owner"] == eid and row_active(x["row"]):
                        add("contractor_past_end", eid, x["account"], app, app, "flag")
            return
        if on_leave(r):
            for u in okta_users:
                if okta_owner[u["id"]] == eid and okta_active(u):
                    add("leave_of_absence", eid, u["profile"]["login"], "okta", "", "suspend")
            for g in g_users:
                if g_owner[g["primaryEmail"]] == eid and not g["suspended"]:
                    add("leave_of_absence", eid, g["primaryEmail"], "google", "", "suspend")
            for s in s_users:
                if s_owner[s["id"]] == eid and s.get("active"):
                    add("leave_of_absence", eid, s["userName"], "slack", "", "suspend")
            # fall through: role checks still apply to their app access

        # Current worker: compare access with the role.
        role = role_of(r)
        u = person_okta.get(eid)
        have_sso = set(assign[u["id"]]) if u else set()
        have_exp = set(person_rows[eid])
        want_sso = want_sso_of(r)
        want_exp = want_exp_of(r)
        evk = {e["kind"] for e in ev_by[eid]}
        mover = "move" in evk
        rehire = "rehire" in evk
        login = u["profile"]["login"] if u else ""
        # hand grants first (drift)
        for app in sorted(have_sso):
            if u and (u["id"], app) in drift_pairs:
                add("drift", eid, login, "okta", app, "remove")
        if mover or rehire:
            ftype = "mover_stale_access" if mover else "rehire"
            for app in sorted(have_sso - want_sso):
                add(ftype, eid, login, "okta", app, "remove")
            for app in sorted(have_exp - want_exp):
                add(ftype, eid, person_rows[eid][app], app, app, "flag")
            if mover:
                for app in sorted(want_sso - have_sso):
                    if u:
                        add(ftype, eid, login, "okta", app, "add")
                for app in sorted(want_exp - have_exp):
                    add(ftype, eid, expected_export_account(eid, app), app, app, "add")
        notes_debug["role_gap"].append((eid, role, sorted(have_sso - want_sso), sorted(want_sso - have_sso),
                                        sorted(have_exp - want_exp), sorted(want_exp - have_exp)))

    def row_active(row):
        st = norm(row.get("status", ""))
        return not (st and st in _INACTIVE_WORDS)

    def expected_export_account(eid, app):
        r = R[eid]
        if not W.exports[app]["username_only"]:
            return norm(r["work_email"])
        pat = export_pattern[app]
        base = render(pat, tokens_for(r))
        taken = {x["account"] for x in export_rows[app] if x["owner"] != eid}
        acct, k = base, 2
        while acct in taken:
            acct, k = f"{base}{k}", k + 1
        return acct

    for eid in sorted(R):
        handle_person_accounts(eid)

    # ------------------------------------------------ accounts nobody owns
    for u in okta_users:
        if okta_owner[u["id"]] is None and u["id"] not in bg_okta_ids and okta_active(u):
            add("orphaned_account", "", u["profile"]["login"], "okta", "", "remove")
            for app in sorted(assign[u["id"]]):
                add("orphaned_account", "", u["profile"]["login"], "okta", app, "remove")
    for g in g_users:
        if g_owner[g["primaryEmail"]] is None and not is_break_glass(g["primaryEmail"]) and not g["suspended"]:
            add("orphaned_account", "", g["primaryEmail"], "google", "", "remove")
    for s in s_users:
        if s_owner[s["id"]] is None and s.get("active"):
            add("orphaned_account", "", s["userName"], "slack", "", "remove")
    for app, rows in export_rows.items():
        for x in rows:
            if x["owner"] is None and row_active(x["row"]) and not is_break_glass(x["account"]):
                add("orphaned_account", "", x["account"], app, app, "flag")

    # ------------------------------------------------ remaining hand grants (drift)
    for (uid, app) in sorted(drift_pairs):
        u = ou_by_id[uid]
        add("drift", okta_owner[uid] or "", u["profile"]["login"], "okta", app, "remove")

    debug = {"role_sso": role_sso_extra, "role_exp": role_exp_pol, "birthright": birthright,
             "export_pattern": export_pattern, "export_rows": export_rows,
             "person_okta": person_okta, "person_rows": person_rows, "R": R,
             "notes": notes_debug, "bulk": bulk_people, "dup": dup_records,
             "future_term": future_term, "okta_owner": okta_owner, "g_owner": g_owner,
             "s_owner": s_owner, "role_of": role_of, "assign": assign}
    out = sorted(findings.values(), key=lambda f: (f["type"], f["employee_id"], f["system"],
                                                   f["app_id"], f["account"], f["expected_action"]))
    return out, debug


def main(argv):
    if len(argv) != 3:
        sys.stderr.write("usage: referee.py WORLD_DIR OUT_JSON\n")
        return 2
    findings, _ = build(argv[1])
    data = json.dumps({"findings": findings}, ensure_ascii=False, indent=1, sort_keys=True)
    Path(argv[2]).write_text(data + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
